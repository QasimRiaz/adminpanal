<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-17 17:55:30 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-17 17:58:01 --> 404 Page Not Found: admin/Change_pwd/index
