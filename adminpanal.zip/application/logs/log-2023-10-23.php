<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-23 18:59:08 --> 404 Page Not Found: admin/Change_pwd/index
ERROR - 2023-10-23 19:05:07 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-23 19:26:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Setting_model C:\xampp\htdocs\adminpanal\system\core\Loader.php 348
ERROR - 2023-10-23 19:26:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Setting_model C:\xampp\htdocs\adminpanal\system\core\Loader.php 348
ERROR - 2023-10-23 19:27:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Setting_model C:\xampp\htdocs\adminpanal\system\core\Loader.php 348
ERROR - 2023-10-23 19:27:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Setting_model C:\xampp\htdocs\adminpanal\system\core\Loader.php 348
ERROR - 2023-10-23 19:35:31 --> 404 Page Not Found: Add/index
ERROR - 2023-10-23 19:37:00 --> 404 Page Not Found: Admin/dashboard
ERROR - 2023-10-23 19:38:54 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-23 19:39:05 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-23 19:39:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-23 19:40:18 --> 404 Page Not Found: Admin/dashboard
ERROR - 2023-10-23 19:40:46 --> 404 Page Not Found: Admin/dashboard
ERROR - 2023-10-23 19:41:52 --> 404 Page Not Found: Admin/dashboard
ERROR - 2023-10-23 19:41:55 --> 404 Page Not Found: Admin/dashboard
ERROR - 2023-10-23 21:51:14 --> Severity: error --> Exception: Call to undefined method CI_Session::unset_flashdata() C:\xampp\htdocs\adminpanal\application\controllers\Auth.php 19
ERROR - 2023-10-23 19:52:48 --> 404 Page Not Found: Admin/admin
ERROR - 2023-10-23 19:53:03 --> 404 Page Not Found: Admin/admin
ERROR - 2023-10-23 19:53:05 --> 404 Page Not Found: Admin/admin
ERROR - 2023-10-23 19:53:31 --> 404 Page Not Found: Admin/admin
ERROR - 2023-10-23 19:55:47 --> 404 Page Not Found: Profile/index
ERROR - 2023-10-23 19:55:56 --> 404 Page Not Found: Profile/index
ERROR - 2023-10-23 19:56:02 --> 404 Page Not Found: User/profile
ERROR - 2023-10-23 19:56:07 --> 404 Page Not Found: Auth/profile
ERROR - 2023-10-23 19:56:11 --> 404 Page Not Found: Admin/profile
ERROR - 2023-10-23 19:57:37 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-23 22:02:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model C:\xampp\htdocs\adminpanal\system\core\Loader.php 348
ERROR - 2023-10-23 22:02:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model C:\xampp\htdocs\adminpanal\system\core\Loader.php 348
