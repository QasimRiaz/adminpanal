<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-18 19:37:23 --> Severity: error --> Exception: Call to undefined method CI_Session::unset_flashdata() C:\xampp\htdocs\adminpanal\application\views\admin\includes\_messages.php 6
ERROR - 2023-10-18 19:37:25 --> Severity: error --> Exception: Call to undefined method CI_Session::unset_flashdata() C:\xampp\htdocs\adminpanal\application\views\admin\includes\_messages.php 6
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined variable $sdata C:\xampp\htdocs\adminpanal\application\models\admin\Complaints_model.php 122
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\adminpanal\application\models\admin\Complaints_model.php 122
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "reportedby" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 111
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "designation" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 115
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "mobileno" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 118
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "loction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 121
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "subloction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 124
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "subloction2" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 127
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "loctiondetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 130
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "workorderdetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 133
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "comstatus" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 136
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "comtype" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 139
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 142
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 145
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
ERROR - 2023-10-18 19:54:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 151
ERROR - 2023-10-18 19:57:53 --> Severity: error --> Exception: Call to undefined method Complaints_model::update_post_meta() C:\xampp\htdocs\adminpanal\application\models\admin\Complaints_model.php 124
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 142
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "reportedby" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 111
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "designation" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 115
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "mobileno" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 118
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "loction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 121
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "subloction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 124
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "subloction2" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 127
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "loctiondetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 130
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "workorderdetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 133
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "comstatus" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 136
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "comtype" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 139
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 142
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 145
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
ERROR - 2023-10-18 19:59:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 151
ERROR - 2023-10-18 19:59:59 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 142
ERROR - 2023-10-18 19:59:59 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
ERROR - 2023-10-18 20:05:27 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 142
ERROR - 2023-10-18 20:05:27 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
ERROR - 2023-10-18 20:05:27 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 142
ERROR - 2023-10-18 20:05:27 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
ERROR - 2023-10-18 20:17:31 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 142
ERROR - 2023-10-18 20:17:31 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
ERROR - 2023-10-18 20:21:02 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 148
