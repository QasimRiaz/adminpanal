<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-11 03:58:24 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 03:58:24 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 03:58:24 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 03:58:25 --> 404 Page Not Found: Img/favicon.ico
ERROR - 2023-10-11 03:58:39 --> 404 Page Not Found: Login/index
ERROR - 2023-10-11 03:58:44 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 03:58:44 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 03:58:44 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 04:06:16 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 04:06:16 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 04:06:16 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-11 04:18:59 --> 404 Page Not Found: Assets/dist
