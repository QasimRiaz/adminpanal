<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-21 16:01:37 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:01:37 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:02:51 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:03:06 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:03:08 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:03:09 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:03:13 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:03:33 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:03:35 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:09:14 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:09:20 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 16:10:12 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 18:36:53 --> Query error: No tables used - Invalid query: SELECT *
WHERE `ci_posts`.`post_author` = '32'
AND `ci_posts`.`post_type` = 'blogworkorder'
ORDER BY `ci_posts`.`ID` DESC
ERROR - 2023-10-21 16:38:30 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-21 18:45:09 --> Severity: error --> Exception: Call to undefined method Complaints_model::add_new_complaints() C:\xampp\htdocs\adminpanal\application\controllers\admin\Complaints.php 134
ERROR - 2023-10-21 18:49:46 --> Severity: error --> Exception: Call to undefined method Complaints_model::add_new_complaints() C:\xampp\htdocs\adminpanal\application\controllers\admin\Complaints.php 134
ERROR - 2023-10-21 18:51:38 --> Severity: error --> Exception: Call to undefined method Complaints_model::add_new_complaints() C:\xampp\htdocs\adminpanal\application\controllers\admin\Complaints.php 134
ERROR - 2023-10-21 18:53:43 --> Severity: Warning --> Undefined variable $loggedInuser_info C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
ERROR - 2023-10-21 18:53:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
ERROR - 2023-10-21 18:53:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
ERROR - 2023-10-21 18:54:37 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
ERROR - 2023-10-21 18:58:06 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
ERROR - 2023-10-21 18:58:06 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
ERROR - 2023-10-21 18:58:59 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
ERROR - 2023-10-21 18:59:07 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 110
