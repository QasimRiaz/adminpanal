<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-15 06:48:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'adminlite_db' C:\xampp\htdocs\adminpanal\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-10-15 06:48:27 --> Unable to connect to the database
ERROR - 2023-10-15 07:00:22 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-15 07:01:36 --> 404 Page Not Found: Assets/img
ERROR - 2023-10-15 07:01:46 --> 404 Page Not Found: Assets/img
ERROR - 2023-10-15 07:01:46 --> 404 Page Not Found: Assets/img
ERROR - 2023-10-15 07:01:46 --> 404 Page Not Found: Assets/img
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "post_id" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 27
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "post_id" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 30
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "reportedby" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 33
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "designation" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 37
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "mobileno" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 40
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "loction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 43
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "subloction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 46
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "subloction2" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 49
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "loctiondetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 52
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "workorderdetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 55
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "comstatus" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 58
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "comtype" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 61
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 64
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 67
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 70
ERROR - 2023-10-15 10:06:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 73
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "reportedby" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 33
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "designation" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 37
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "mobileno" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 40
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "loction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 43
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "subloction" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 46
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "subloction2" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 49
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "loctiondetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 52
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "workorderdetails" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 55
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "comstatus" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 58
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "comtype" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 61
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 64
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "tag" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 67
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 70
ERROR - 2023-10-15 10:39:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\list.php 73
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 19
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 24
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 31
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 39
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 47
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 54
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 63
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 64
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 83
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 83
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 83
ERROR - 2023-10-15 11:26:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 83
ERROR - 2023-10-15 09:39:44 --> Severity: Compile Error --> Cannot redeclare Dashboard::index() C:\xampp\htdocs\adminpanal\application\controllers\admin\Dashboard.php 40
ERROR - 2023-10-15 09:39:47 --> Severity: Compile Error --> Cannot redeclare Dashboard::index() C:\xampp\htdocs\adminpanal\application\controllers\admin\Dashboard.php 40
ERROR - 2023-10-15 09:43:58 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-15 09:43:58 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-15 09:43:58 --> 404 Page Not Found: Assets/lib
ERROR - 2023-10-15 09:44:11 --> 404 Page Not Found: Img/favicon.ico
ERROR - 2023-10-15 10:52:06 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-15 10:52:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-15 10:52:17 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-15 10:52:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-15 11:13:53 --> 404 Page Not Found: admin/Complaints/list
ERROR - 2023-10-15 11:14:05 --> 404 Page Not Found: admin/Complaints/list
ERROR - 2023-10-15 11:14:19 --> 404 Page Not Found: admin/Complaints/list
ERROR - 2023-10-15 11:14:59 --> 404 Page Not Found: admin/Complaints/list
ERROR - 2023-10-15 11:18:19 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-15 13:44:54 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting "elseif" or "else" or "endif" C:\xampp\htdocs\adminpanal\application\views\admin\includes\_header.php 135
ERROR - 2023-10-15 13:45:21 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\adminpanal\application\views\admin\includes\_header.php 105
ERROR - 2023-10-15 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\includes\_header.php 105
ERROR - 2023-10-15 12:06:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 12:06:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-10-15 17:20:54 --> 404 Page Not Found: Complaints/index
ERROR - 2023-10-15 17:47:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 19
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 24
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 31
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 39
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 47
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 54
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 63
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 64
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 83
ERROR - 2023-10-15 20:04:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 83
