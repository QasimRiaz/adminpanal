<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-22 08:33:57 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-22 08:34:06 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-10-22 10:47:55 --> Severity: error --> Exception: Call to undefined function size() C:\xampp\htdocs\adminpanal\application\models\admin\Dashboard_model.php 53
ERROR - 2023-10-22 15:38:10 --> 404 Page Not Found: admin/Auth/singup
ERROR - 2023-10-22 15:38:20 --> 404 Page Not Found: admin/Auth/signeup
ERROR - 2023-10-22 17:38:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 17:38:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 17:38:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 17:38:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 15:38:38 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 17:39:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 17:39:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 17:39:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 17:39:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\helpers\functions_helper.php 108
ERROR - 2023-10-22 15:39:31 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 15:41:49 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 15:45:50 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 15:46:30 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 16:01:44 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 16:03:13 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 17:04:25 --> 404 Page Not Found: Assets/dist
ERROR - 2023-10-22 17:11:29 --> 404 Page Not Found: Assets/dist
