<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-20 19:29:17 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 122
ERROR - 2023-10-20 19:29:17 --> Severity: Warning --> Undefined array key "issuepicture" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 152
ERROR - 2023-10-20 19:29:17 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 122
ERROR - 2023-10-20 19:34:25 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 122
ERROR - 2023-10-20 19:34:25 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 122
ERROR - 2023-10-20 19:41:25 --> Severity: error --> Exception: syntax error, unexpected token "if" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\index.php 112
ERROR - 2023-10-20 17:57:35 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 17:57:35 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 17:57:39 --> 404 Page Not Found: admin/Complaints/assets
ERROR - 2023-10-20 17:58:18 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 17:58:18 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined array key "ID" C:\xampp\htdocs\adminpanal\application\models\admin\Complaints_model.php 44
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 19
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 19
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 24
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 24
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 31
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 31
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 39
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 39
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 46
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 46
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 54
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 54
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 62
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 62
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 69
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 69
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 78
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 78
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 79
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 79
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 98
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 98
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Undefined variable $admin C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 98
ERROR - 2023-10-20 20:33:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\adminpanal\application\views\admin\admin\edit.php 98
ERROR - 2023-10-20 20:37:53 --> Severity: Warning --> Undefined array key "ID" C:\xampp\htdocs\adminpanal\application\models\admin\Complaints_model.php 44
ERROR - 2023-10-20 20:50:43 --> Severity: Warning --> Undefined array key "compnay_name" C:\xampp\htdocs\adminpanal\application\views\admin\complaints\edit.php 68
ERROR - 2023-10-20 19:15:10 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:15:10 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 21:16:44 --> Severity: Warning --> Undefined variable $postID C:\xampp\htdocs\adminpanal\application\models\admin\Complaints_model.php 122
ERROR - 2023-10-20 21:16:44 --> Query error: Column 'post_id' cannot be null - Invalid query: INSERT INTO `ci_postmeta` (`post_id`, `meta_key`, `meta_value`) VALUES (NULL, 'reportedby', 'Abc')
ERROR - 2023-10-20 19:17:53 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:17:53 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:18:07 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:18:07 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:21:00 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:21:00 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:21:30 --> 404 Page Not Found: Oprator/index
ERROR - 2023-10-20 19:21:30 --> 404 Page Not Found: Oprator/index
